import random
def main():
    print("Welcome to the game")
   # Pick a random number between 1 and 100
    secret = random.randint(1, 100)
    tries = 0
    guess = -1  # initialize with a number that can't be correct

    while guess != secret:
        guess = int(input("Guess a number between 1 and 100: "))
        tries += 1

        if guess < secret:
            print("Too low!")
        elif guess > secret:
            print("Too high!")
        
    print(f"Congratulations! You guessed it in {tries} tries.")


if __name__ == "__main__":
    main()